import sqlite3
from config import DB_PATH

class WarDatabase:
    def __init__(self):
        self.db_path = DB_PATH
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS telemetry (id INTEGER PRIMARY KEY CHECK (id=1), px REAL, pz REAL, mission TEXT)')
        c.execute('INSERT OR IGNORE INTO telemetry (id, px, pz, mission) VALUES (1, 4800.0, 6300.0, "Game Master")')
        conn.commit()
        conn.close()

    def update_telemetry(self, px, pz, m):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('UPDATE telemetry SET px=?, pz=?, mission=? WHERE id=1', (px, pz, m))
        conn.commit()
        conn.close()

    def get_pos(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('SELECT px, pz, mission FROM telemetry WHERE id=1')
        res = c.fetchone()
        conn.close()
        return res if res else (4800.0, 6300.0, "Game Master")
