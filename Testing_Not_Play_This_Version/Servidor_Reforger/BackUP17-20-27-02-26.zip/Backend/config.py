import json
HOST = '0.0.0.0'
PORT = 8000
OLLAMA_URL = 'http://localhost:11434/api/generate'
MODEL_NAME = 'llama3.1'
AI_TIMEOUT = 40.0
DB_PATH = 'war_room.db'
PREFABS_PATH = '../prefabs.json'

def load_prefabs():
    try:
        with open(PREFABS_PATH, 'r', encoding='utf-8') as f: return json.load(f)
    except:
        return {'US Escuadra de Fusileros': '{DDF3799FA1387848}Prefabs/Groups/BLUFOR/Group_US_RifleSquad.et'}

PREFABS = load_prefabs()
