import json, httpx
from config import OLLAMA_URL, MODEL_NAME, AI_TIMEOUT, PREFABS

class ZeusAIAgent:
    def __init__(self, war_db, command_queue, action_history):
        self.war_db = war_db
        self.queue = command_queue
        self.history = action_history

    async def process_order(self, prompt):
        px, pz, mission = self.war_db.get_pos()
        sys_prompt = f"Eres Zeus de Arma Reforger. Jugador en X:{int(px)} Z:{int(pz)}. Mision: {mission}. Responde SOLO JSON con unit_id ({list(PREFABS.keys())}), grid_x, grid_z e internal_thought."
        
        payload = {'model': MODEL_NAME, 'prompt': prompt, 'system': sys_prompt, 'stream': False, 'format': 'json'}
        
        async with httpx.AsyncClient() as client:
            try:
                r = await client.post(OLLAMA_URL, json=payload, timeout=AI_TIMEOUT)
                data = json.loads(r.json()['response'])
                uid = data.get('unit_id')
                gx, gz = data.get('grid_x', -1), data.get('grid_z', -1)
                
                final_x = px + 15 if gx <= 0 else (gx * 100 if gx < 1000 else gx)
                final_z = pz + 15 if gz <= 0 else (gz * 100 if gz < 1000 else gz)

                if uid in PREFABS:
                    self.queue.append({'path': PREFABS[uid], 'x': final_x, 'z': final_z})
                    self.history.append(f"🧠 IA: {data.get('internal_thought', 'Despliegue tactico')} -> {uid}")
            except Exception as e:
                self.history.append(f"❌ ERROR IA: {str(e)}")
