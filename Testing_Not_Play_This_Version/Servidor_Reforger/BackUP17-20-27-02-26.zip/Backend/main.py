import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

from config import HOST, PORT
from database import WarDatabase
from ai_agent import ZeusAIAgent

# ==========================================
# 🛡️ LISTA BLANCA DE COMANDANTES
# ==========================================
WHITELIST = ["Raulote", "ComandanteAlfa"]

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_methods=['*'], allow_headers=['*'])

command_queue = []
action_history = []
war_db = WarDatabase()
zeus_ai = ZeusAIAgent(war_db, command_queue, action_history)

class ManualOrder(BaseModel): 
    player_name: str
    order: str

@app.post('/manual_command')
async def manual_command(o: ManualOrder):
    # Comprobación de seguridad
    if o.player_name not in WHITELIST:
        action_history.append(f"⛔ DENEGADO: '{o.player_name}' intentó dar una orden a Zeus.")
        return {'status': 'denied'}

    # Si el nombre es correcto, ejecutamos la orden
    action_history.append(f"👤 ORDEN ({o.player_name}): {o.order}")
    await zeus_ai.process_order(o.order)
    return {'status': 'ok'}

@app.get('/arma_sync', response_class=PlainTextResponse)
async def arma_sync(px: float = 0, pz: float = 0, m: str = "GM"):
    # Guardar telemetría
    war_db.update_telemetry(px, pz, m)
    
    # Enviar tropas si hay en cola
    if command_queue:
        c = command_queue.pop(0)
        return f"SPAWN|{c['path']}|{c['x']}|0|{c['z']}"
    return 'NONE'

@app.get('/status')
async def status():
    # Devuelve los últimos 15 mensajes para que la Web los lea
    return {'history': action_history[-15:]}

if __name__ == '__main__':
    print(f"🚀 Servidor Python Iniciado en puerto {PORT}...")
    uvicorn.run(app, host=HOST, port=PORT)